package com.btmedia.assamesekeyboard
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.content.Context
import android.view.inputmethod.InputMethodManager
import android.widget.*
class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val l=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,40,32,32) }
  l.addView(TextView(this).apply { text="BT Assamese Keyboard"; textSize=24f })
  l.addView(TextView(this).apply { text="Enable the keyboard in Settings, then select it from the input-method picker."; textSize=16f })
  l.addView(Button(this).apply { text="Enable Keyboard"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } })
  l.addView(Button(this).apply { text="Select Keyboard"; setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } })
  setContentView(l)
 }
}
