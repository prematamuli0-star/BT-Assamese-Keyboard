package com.btmedia.assamesekeyboard
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Button
import android.graphics.Color
class BTKeyboardService: InputMethodService() {
 private var english=false
 override fun onCreateInputView(): View = keyboard()
 private fun keyboard(): View {
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(225,239,255)); setPadding(4,4,4,4) }
  val rows=if(english) listOf(listOf("q","w","e","r","t","y","u","i","o","p"),listOf("a","s","d","f","g","h","j","k","l"),listOf("z","x","c","v","b","n","m","⌫"),listOf("অসমীয়া","space","↵")) else listOf(listOf("অ","আ","ই","ঈ","উ","ঊ","ঋ","এ","ঐ","ও"),listOf("ক","খ","গ","ঘ","ঙ","চ","ছ","জ","ঝ"),listOf("ট","ঠ","ড","ঢ","ণ","ত","থ","দ","ধ"),listOf("ন","প","ফ","ব","ভ","ম","য","ৰ","ল"),listOf("ৱ","শ","ষ","স","হ","ক্ষ","ড়","ঢ়","য়"),listOf("English","space","⌫","↵"))
  rows.forEach { row -> val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
   row.forEach { k -> val b=Button(this).apply { text=if(k=="space") "␣" else k; textSize=16f; setPadding(0,0,0,0); setOnClickListener { key(k) } }
    val p=LinearLayout.LayoutParams(0,48,1f); p.setMargins(2,2,2,2); line.addView(b,p) }
   root.addView(line)
  }; return root
 }
 private fun key(k:String) { val ic=currentInputConnection ?: return; when(k) { "⌫"->ic.deleteSurroundingText(1,0); "↵"->ic.commitText("\n",1); "space"->ic.commitText(" ",1); "English","অসমীয়া"->{english=!english; setInputView(keyboard())}; else->ic.commitText(k,1) } }
}
