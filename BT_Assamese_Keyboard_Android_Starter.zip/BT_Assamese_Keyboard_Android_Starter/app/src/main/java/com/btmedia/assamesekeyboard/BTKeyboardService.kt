package com.btmedia.assamesekeyboard

import android.app.AlertDialog
import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView

class BTKeyboardService : InputMethodService() {
    private var english = false
    private var heightDp = 260
    private val blue = Color.rgb(35, 105, 210)
    private val pale = Color.rgb(232, 242, 255)
    private val white = Color.WHITE
    private val dark = Color.rgb(35, 45, 60)

    override fun onCreateInputView(): View = keyboard()

    private fun keyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            layoutParams = LinearLayout.LayoutParams(-1, dp(heightDp))
        }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("☰", "😊", "📋", "🌐", "🎙", "⌕", "⚙").forEachIndexed { index, label ->
            val b = toolButton(label)
            b.setOnClickListener {
                when (index) {
                    0 -> resizeDialog()
                    1 -> commit("😊")
                    2 -> showToast("Clipboard feature coming soon")
                    3 -> { english = !english; setInputView(keyboard()) }
                    4 -> showToast("Voice typing depends on Android voice input")
                    5 -> showToast("Search toolbar coming soon")
                    6 -> settingsDialog()
                }
            }
            toolbar.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        root.addView(toolbar)
        val suggestions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(4)) }
        listOf(if (english) "Hello" else "মোৰ", if (english) "Name" else "নাম", if (english) "Assamese" else "অসমীয়া", "▼").forEach { s ->
            val t = TextView(this).apply { text=s; textSize=16f; setTextColor(blue); gravity=Gravity.CENTER; setPadding(dp(4),0,dp(4),0) }
            suggestions.addView(t, LinearLayout.LayoutParams(0, dp(30), 1f))
        }
        root.addView(suggestions)

        val rows = if (english) listOf(
            listOf("Q","W","E","R","T","Y","U","I","O","P"),
            listOf("A","S","D","F","G","H","J","K","L"),
            listOf("⇧","Z","X","C","V","B","N","M","⌫"),
            listOf("123","😊","English","space",".,?","↵")
        ) else listOf(
            listOf("অ","আ","ই","ঈ","উ","ঊ","ঋ","এ","ঐ","ও"),
            listOf("ক","খ","গ","ঘ","ঙ","চ","ছ","জ","ঝ"),
            listOf("ট","ঠ","ড","ঢ","ণ","ত","থ","দ","ধ"),
            listOf("ন","প","ফ","ব","ভ","ম","য","ৰ","ল"),
            listOf("ৱ","শ","ষ","স","হ","ক্ষ","ড়","ঢ়","য়"),
            listOf("123","😊","English","space","⌫","↵")
        )
        rows.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
            row.forEach { key ->
                val special = key in listOf("123","English","space","⌫","↵","⇧","😊")
                val b = Button(this).apply {
                    text = if (key == "space") "␣" else key
                    textSize = if (key == "space") 14f else 17f
                    setTextColor(if (special) blue else dark)
                    setBackgroundColor(if (special) Color.rgb(210,226,250) else white)
                    typeface = Typeface.DEFAULT
                    setPadding(0,0,0,0)
                    minWidth=0; minimumWidth=0; minHeight=0; minimumHeight=0
                    setOnClickListener { handleKey(key) }
                }
                val weight = if (key == "space") 3f else 1f
                val lp = LinearLayout.LayoutParams(0, dp(if (rowIndex==rows.lastIndex) 42 else 40), weight)
                lp.setMargins(dp(2),dp(2),dp(2),dp(2))
                line.addView(b, lp)
            }
            root.addView(line)
        }
        return root
    }

    private fun toolButton(label: String) = Button(this).apply {
        text=label; textSize=18f; setTextColor(blue); setBackgroundColor(pale); minWidth=0; minimumWidth=0; setPadding(0,0,0,0)
    }

    private fun handleKey(k: String) {
        when (k) {
            "⌫" -> currentInputConnection?.deleteSurroundingText(1,0)
            "↵" -> commit("\n")
            "space" -> commit(" ")
            "English", "অসমীয়া" -> { english=!english; setInputView(keyboard()) }
            "123" -> showToast("Numbers layout coming soon")
            "😊" -> commit("😊")
            "⇧" -> showToast("Shift mode coming soon")
            else -> commit(if (english) k.lowercase() else k)
        }
    }
    private fun commit(s: String) { currentInputConnection?.commitText(s,1) }
    private fun resizeDialog() {
        val options = arrayOf("Small", "Medium", "Large", "Reset default")
        AlertDialog.Builder(this).setTitle("Keyboard size")
            .setItems(options) { _, which ->
                heightDp = when(which) { 0 -> 220; 1 -> 260; 2 -> 310; else -> 260 }
                setInputView(keyboard())
            }.show()
    }
    private fun settingsDialog() {
        AlertDialog.Builder(this).setTitle("BT Keyboard Settings")
            .setItems(arrayOf("Keyboard size", "Language: Assamese / English", "Theme: Blue + White")) { _, which ->
                if (which == 0) resizeDialog() else if (which == 1) { english=!english; setInputView(keyboard()) } else showToast("Blue + White theme selected")
            }.show()
    }
    private fun showToast(message: String) { android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
